<?php
$db = mysqli_connect("localhost", "root", "", "jwd") or die("Koneksi Server Gagal");
